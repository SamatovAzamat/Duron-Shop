﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","eo",{title:"Informo pri la elemento",dialogName:"Nomo de la dialogfenestro",tabName:"Langetnomo",elementId:"ID de la elemento",elementType:"Tipo de la elemento"});