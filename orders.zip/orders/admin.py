from django.contrib import admin

from orders.models import OrderModel

admin.site.register(OrderModel)
